#!/bin/sh
#Setting  reminder
text=$1
countdown=$2
printf "\033[2J\033[H" #clearing terminal using ANSI escape sequence
if [ "$1" == "" ] || [ "$2" == "" ]
then
        countdown=30
        text="You have started reminder, what have you forgotten?"
        echo ""
        printf "\033[1;32m"
fi
echo ""
echo "$text..."
echo "Timer=$countdown seconds..."
echo ""
echo "Press Ctrl-C in this window to stop..."
echo ""
> /tmp/reminder.sh
chmod 755 /tmp/reminder.sh
echo "#!/bin/sh" >> /tmp/reminder.sh
echo "printf '\033[1m\033[12;3f$text\033[0m\n\n\n'" >> /tmp/reminder.sh
echo "sleep 3" >> /tmp/reminder.sh
echo "exit 0" >> /tmp/reminder.sh
while true
do
        xterm -e /tmp/reminder.sh &
        sleep $countdown
done



